/**
 * Package contains all data transfer objects needed.
 * 
 * @author Junyang HE
 *
 */
package model;