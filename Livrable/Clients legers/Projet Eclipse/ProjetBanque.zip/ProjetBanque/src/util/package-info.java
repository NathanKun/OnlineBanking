/**
 * Package contains all utils need by the projet.
 * 
 * @author Junyang HE
 *
 */
package util;