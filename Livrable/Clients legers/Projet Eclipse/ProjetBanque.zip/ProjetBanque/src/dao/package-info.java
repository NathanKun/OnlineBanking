/**
 * Package contains all data access objects needed.
 * 
 * @author Junyang HE
 *
 */
package dao;