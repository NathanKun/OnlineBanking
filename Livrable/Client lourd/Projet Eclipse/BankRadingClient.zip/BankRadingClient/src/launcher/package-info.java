/**
 * BankRadingClient Launcher
 * 
 * @author Junyang HE
 *
 */
package launcher;