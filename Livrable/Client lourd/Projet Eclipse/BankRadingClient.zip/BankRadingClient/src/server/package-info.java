/**
 * Package contains server part class
 */
/**
 * Server package, contains server part class
 * @author Junyang HE
 *
 */
package server;